'''
Author:Shreyas Naik
Date: 16-12-2025
'''

a = int(input('Enter First Number: '))
com = input('Choose an operator (+,-,*,/,**,//): ')
b = int(input('Enter Second Number: '))

if com == '+':
    print(a+b)
elif com == '-':
    print(a-b)
elif com == '*':
    print(a*b)
elif com == '/':
    print(a/b)
elif com == '**':
    print(a**b)
elif com == '//':
    print(a//b)
else:
    print('invalid input, try again')