'''
Author: Shreyas Naik
Date: 16-12-2025
'''

name = input('Welcome, Please enter your name: ')

blacklisted = ['shreyas','osama','jamal','walter']

if name.strip().lower() in blacklisted:
    print('You are restricted')
else:
    print('Hello,',name)