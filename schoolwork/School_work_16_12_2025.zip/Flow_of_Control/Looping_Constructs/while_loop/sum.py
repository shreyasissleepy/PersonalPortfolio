#Program 6-13
#Find the sum of all the positive numbers entered by the user
#till the user enters a negative number.

entry = 0
sum1 = 0
print("Enter numbers to find their sum, negative number ends theloop:")
while True:
#int() typecasts string to integer
 entry = int(input())
 if (entry < 0):
    break
 sum1 += entry
print("Sum =", sum1)