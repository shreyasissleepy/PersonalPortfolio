#Program 6-11
#Find the factors of a number using while loop

num = int(input("Enter a number to find its factor: "))
print (1, end=' ') #1 is a factor of every number
factor = 2
while factor <= num/2 :
    if num % factor == 0:
        #the optional parameter end of print function specifies the delimeter
        #blank space(' ') to print next value on same line
        print(factor, end=' ')

    factor += 1

print (num, end=' ') #every number is a factor of itself