'''
Author: Shreyas Naik
Date: 16-12-2025
'''

num1 = 10.0
num2 = int(input("num2 = "))
#if user inputs a string or a zero, it leadsto runtime error
print(num1/num2)