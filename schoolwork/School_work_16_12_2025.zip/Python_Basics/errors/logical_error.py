'''
Author: Shreyas Naik
Date: 16-12-2025
'''

#find average of two numbers

a = int(input('Enter first number: '))
b = int(input('Enter second number: '))

avg = a + b/2 #syntax is correct, but the output is not desired

print('Average of the two numbers is',avg) #Incorrect

avg = (a+b)/2 #Desired output obtained

print('Average of the two numbers is',avg) #Correct