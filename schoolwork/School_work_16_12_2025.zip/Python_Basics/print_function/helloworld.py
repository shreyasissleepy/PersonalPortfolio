'''
Author: Shreyas Naik
Date: 15-12-2025
'''

print('Hello World')