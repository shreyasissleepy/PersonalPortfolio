'''
Author: Shreyas Naik
Date:15-12-2025
'''

print(1 == 0) #False
print(1 > 0)  #True
print(1 < 0)  #False
print(1 >= 0) #True
print(1 <= 0) #False
print(1 != 0) #True

'''
Use of Membership operators
'''

list1 = ['Neil','Nitin','Mukesh']

print('Neil' in list1) #True
print('Samarth' in list1) #False

print('Samarth' not in list1) #True