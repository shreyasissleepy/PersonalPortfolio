'''
Author: Shreyas Naik
Date:15-12-2025
'''

#Mapping data construct

Person1 = {
    'name':'Shreyas Naik',
    'age':16,
    'gender':'Unclassified'
}

Person2 = {
    'name':'Meghna Barua',
    'age':31,
    'gender':'Female'
}

Person3 = {
    'name':'Gaurish Apte',
    'age':17,
    'gender':'Male'
}

print(Person1['name'],Person1['age'],Person1['gender'])
print(Person2['name'],Person2['age'],Person2['gender'])
print(Person3['name'],Person3['age'],Person3['gender'])