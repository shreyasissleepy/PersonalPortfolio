'''
Author: Shreyas Naik
Date:15-12-2025
'''

list1 = ['Shreyas','Naman','Vijay','Ashish']

for x in list1:
    print(x)