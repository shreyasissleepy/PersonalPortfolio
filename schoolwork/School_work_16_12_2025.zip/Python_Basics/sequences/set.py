'''
Author: Shreyas Naik
Date:15-12-2025
'''

set1 = {1,2,1,2,1,4,5,5,7,8,7,8,111,4,5,1,1,1,2,5}

print(set1) #no duplicate items in set