'''''
Author: Shreyas Naik
Date: 15-12-2025
'''

a = int(input('Enter length of rectangle: '))
b = int(input('Enter breadth of reactangle: '))

print('Area of Rectangle is',a*b,'sq.unit')